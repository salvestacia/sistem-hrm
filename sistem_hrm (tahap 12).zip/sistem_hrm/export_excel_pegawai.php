<?php
// Memulai sesi dan memastikan pengguna sudah login
session_start();
if (!isset($_SESSION['logged_in'])) {
    header("Location: http://localhost/sistem_hrm/index.php");
    exit();
}

// Mengimpor autoloader Composer
require 'vendor/autoload.php';

use PhpOffice\PhpSpreadsheet\Spreadsheet;
use PhpOffice\PhpSpreadsheet\Writer\Xlsx;

// Koneksi ke database
include "config/koneksi.php";

// Query untuk mendapatkan data karyawan
$query = "SELECT * FROM pegawai";
$result = mysqli_query($koneksi, $query);

// Membuat objek Spreadsheet baru
$spreadsheet = new Spreadsheet();
$sheet = $spreadsheet->getActiveSheet();

// Menambahkan header kolom
$sheet->setCellValue('A1', 'NIK');
$sheet->setCellValue('B1', 'Nama');
$sheet->setCellValue('C1', 'Alamat');
$sheet->setCellValue('D1', 'Tanggal Lahir');
$sheet->setCellValue('E1', 'Status');
$sheet->setCellValue('F1', 'Gaji Pokok');
$sheet->setCellValue('G1', 'Hari Kerja');
$sheet->setCellValue('H1', 'Jam Kerja');
$sheet->setCellValue('I1', 'Username');
$sheet->setCellValue('J1', 'Email');
$sheet->setCellValue('K1', 'Password');
$sheet->setCellValue('L1', 'Hak Akses');

// Menambahkan data karyawan ke file Excel
$rowNumber = 2; // Mulai dari baris kedua untuk data
while ($row = mysqli_fetch_assoc($result)) {
    $sheet->setCellValue('A' . $rowNumber, $row['nik']);
    $sheet->setCellValue('B' . $rowNumber, $row['nama']);
    $sheet->setCellValue('C' . $rowNumber, $row['alamat']);
    $sheet->setCellValue('D' . $rowNumber, $row['tgl_lahir']);
    $sheet->setCellValue('E' . $rowNumber, $row['status_pegawai']);
    $sheet->setCellValue('F' . $rowNumber, $row['gaji_pokok']);
    $sheet->setCellValue('G' . $rowNumber, $row['hari_kerja_1_bulan']);
    $sheet->setCellValue('H' . $rowNumber, $row['jam_kerja_1_hari']);
    $sheet->setCellValue('I' . $rowNumber, $row['username']);
    $sheet->setCellValue('J' . $rowNumber, $row['email']);
    $sheet->setCellValue('K' . $rowNumber, $row['password']);
    $sheet->setCellValue('L' . $rowNumber, $row['id_hak_akses']);
    $rowNumber++;
}

// Menyimpan file Excel ke dalam format XLSX
$writer = new Xlsx($spreadsheet);
$filename = 'data_pegawai.xlsx';

header('Content-Type: application/vnd.openxmlformats-officedocument.spreadsheetml.sheet');
header('Content-Disposition: attachment;filename="' . $filename . '"');
header('Cache-Control: max-age=0');

// Output file Excel ke browser
$writer->save('php://output');
exit();
?>

<?php
// Memulai sesi dan memastikan pengguna sudah login
session_start();
if (!isset($_SESSION['logged_in'])) {
    header("Location: http://localhost/sistem_hrm/index.php");
    exit();
}

// Mengimpor autoloader Composer
require 'vendor/autoload.php';

use PhpOffice\PhpSpreadsheet\Spreadsheet;
use PhpOffice\PhpSpreadsheet\Writer\Xlsx;

// Koneksi ke database
include "config/koneksi.php";

// Query untuk mendapatkan data karyawan
$query = "SELECT pegawai.nama, absensi.* FROM pegawai JOIN absensi ON pegawai.id_pegawai = absensi.id_pegawai";
$result = mysqli_query($koneksi, $query);

// Membuat objek Spreadsheet baru
$spreadsheet = new Spreadsheet();
$sheet = $spreadsheet->getActiveSheet();

// Menambahkan header kolom
$sheet->setCellValue('A1', 'Nama');
$sheet->setCellValue('B1', 'Tanggal Tap');
$sheet->setCellValue('C1', 'Status');


// Menambahkan data karyawan ke file Excel
$rowNumber = 2; // Mulai dari baris kedua untuk data
while ($row = mysqli_fetch_assoc($result)) {
    $sheet->setCellValue('A' . $rowNumber, $row['nama']);
    $sheet->setCellValue('B' . $rowNumber, $row['tgl_tap']);
    $sheet->setCellValue('C' . $rowNumber, $row['status']);
   
    $rowNumber++;
}

// Menyimpan file Excel ke dalam format XLSX
$writer = new Xlsx($spreadsheet);
$filename = 'data_presensi.xlsx';

header('Content-Type: application/vnd.openxmlformats-officedocument.spreadsheetml.sheet');
header('Content-Disposition: attachment;filename="' . $filename . '"');
header('Cache-Control: max-age=0');

// Output file Excel ke browser
$writer->save('php://output');
exit();
?>

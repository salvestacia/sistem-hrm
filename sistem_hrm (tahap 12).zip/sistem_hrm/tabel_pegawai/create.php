<?php
session_start(); // Mulai session

// Periksa apakah pengguna sudah login
if (!isset($_SESSION['logged_in'])) {
    // Jika belum login, redirect kembali ke halaman login atau halaman lain
    header("Location: http://localhost/sistem_hrm/index.php");
    exit();
}
?>

<?php
include "../config/koneksi.php";
if(isset($_POST['submit'])){
    // Calculate the next value for id_user
    $id_user_query = "SELECT COALESCE(MAX(id_user), 0) + 1 AS next_id FROM pegawai";
    $id_user_result = $koneksi->query($id_user_query);
    $next_id_user = 1; // Default if the table is empty

    if ($id_user_result && $id_user_result->num_rows > 0) {
        $row = $id_user_result->fetch_assoc();
        $next_id_user = $row['next_id'];
    }

    $nik = $_POST['nik'];
    $nama = $_POST['nama'];
    $alamat = $_POST['alamat'];
    $tgl_lahir = $_POST['tgl_lahir'];
    $gaji_pokok = $_POST['gaji_pokok'];
    $hari_kerja_1_bulan = $_POST['hari_kerja_1_bulan'];
    $jam_kerja_1_hari = $_POST['jam_kerja_1_hari'];
    $username = $_POST['username'];
    $email = $_POST['email'];
    $password = $_POST['password'];
    $id_hak_akses = $_POST['id_hak_akses'];

    $query = "INSERT INTO pegawai (nik, nama, alamat, tgl_lahir, gaji_pokok, 
    hari_kerja_1_bulan, jam_kerja_1_hari, id_user, username, email, password, id_hak_akses, status_pegawai) 
    VALUES ('$nik', '$nama', '$alamat','$tgl_lahir', '$gaji_pokok', '$hari_kerja_1_bulan', '$jam_kerja_1_hari', '$next_id_user', '$username', '$email', '$password', '$id_hak_akses', 'aktif bekerja')";
    $result = mysqli_query($koneksi, $query);

    if(!$result){
        echo "Data gagal ditambahkan!";
    }
    else{
        echo "Data berhasil ditambahkan!";
        header("Location: http://localhost/sistem_hrm/tabel_pegawai/read.php");
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Tambah Data Karyawan</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: #f4f4f4;
            margin: 0;
            padding: 0;
        }

        h1{
            color: #333;
            text-align: center;    
        }

        form {
            background-color: #fff;
            padding: 20px;
            border-radius: 10px;
            max-width: 500px;
            margin: 0 auto;
            border: 2px solid black;    
        }

        label {
            display: block;
            margin-bottom: 5px;
        }

        input[type="text"] {
            width: 95%;
            padding: 8px;
            margin-bottom: 10px;
            border: 1px solid #ccc;
        }

        button[type="submit"]{
            padding: 8px 16px;
            background-color: #80BCBD;
            color: white;
            border: none;
            border-radius: 5px;
            cursor: pointer;
        }
        a.button {
            display: inline-block;
            padding: 8px 16px;
            text-decoration: none;
            background-color: #80BCBD;
            color: white;
            border-radius: 5px;
            cursor: pointer;
        }

        button[type="submit"]:hover, a.button:hover {
            background-color: #AAD9BB;
        }

        select, input[type="date"] {
        width: 95%; 
        padding: 8px; 
        border: 1px solid #ccc; 
        border-radius: 5px; 
        background-color: #fff; 
        }
    </style>
</head>
<body>
    <h1>Tambah Data Karyawan</h1>
    <form method="post">
        <label for="nik">NIK:</label>
        <input type="text" name="nik" id="nik">
        <br>
        <label for="nama">Nama:</label>
        <input type="text" name="nama" id="nama">
        <br>
        <label for="alamat">Alamat:</label>
        <input type="text" name="alamat" id="alamat">
        <br>
        <label for="tgl_lahir">Tanggal Lahir:</label>
        <input type="date" name="tgl_lahir" id="tgl_lahir">
        <br> <br>
        <label for="gaji_pokok">Gaji Pokok:</label>
        <input type="text" name="gaji_pokok" id="gaji_pokok">
        <br>
        <label for="hari_kerja_1_bulan">Hari Kerja 1 Bulan:</label>
        <input type="text" name="hari_kerja_1_bulan" id="hari_kerja_1_bulan">
        <br>
        <label for="jam_kerja_1_hari">Jam Kerja 1 Hari:</label>
        <input type="text" name="jam_kerja_1_hari" id="jam_kerja_1_hari">
        <br>
        <label for="username">Username:</label>
        <input type="text" name="username" id="username">
        <br>
        <label for="email">Email:</label>
        <input type="text" name="email" id="email">
        <br>
        <label for="password">Password:</label>
        <input type="text" name="password" id="password">
        <br>
        <label for="id_hak_akses">Hak Akses:</label>
        <select name="id_hak_akses" id="id_hak_akses">
            <option value="1">Karyawan</option>
            <option value="2">Admin</option>
        </select>
        <br>
        <br>
        <button type="submit" name="submit">Tambah</button>
        <a href="http://localhost/sistem_hrm/tabel_pegawai/read.php" class="button">Kembali</a>
    </form>
    <a href= "http://localhost/sistem_hrm/logout.php" class= "button">logout</a>
</body>
</html>